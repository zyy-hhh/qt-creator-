/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.8
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *label_6;
    QPushButton *pushButton;
    QComboBox *comboBox_5;
    QPushButton *pushButton_3;
    QComboBox *comboBox_4;
    QTextBrowser *textEdit_ReceiveMsg_shidu;
    QTextBrowser *textEdit_ReceiveMsg;
    QComboBox *comboBox_2;
    QComboBox *comboBox_3;
    QTextBrowser *textEdit_ReceiveMsg_wendu;
    QPushButton *pushButton_2;
    QLabel *label_7;
    QTextEdit *textEdit;
    QComboBox *combox_COMx;
    QCustomPlot *customPlot;
    QSplitter *splitter;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1140, 572);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        label_6 = new QLabel(centralwidget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(680, 20, 79, 19));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(480, 230, 100, 27));
        comboBox_5 = new QComboBox(centralwidget);
        comboBox_5->addItem(QString());
        comboBox_5->setObjectName(QString::fromUtf8("comboBox_5"));
        comboBox_5->setGeometry(QRect(560, 190, 93, 27));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(480, 370, 100, 27));
        comboBox_4 = new QComboBox(centralwidget);
        comboBox_4->addItem(QString());
        comboBox_4->setObjectName(QString::fromUtf8("comboBox_4"));
        comboBox_4->setGeometry(QRect(560, 150, 93, 27));
        textEdit_ReceiveMsg_shidu = new QTextBrowser(centralwidget);
        textEdit_ReceiveMsg_shidu->setObjectName(QString::fromUtf8("textEdit_ReceiveMsg_shidu"));
        textEdit_ReceiveMsg_shidu->setGeometry(QRect(730, 20, 111, 191));
        textEdit_ReceiveMsg = new QTextBrowser(centralwidget);
        textEdit_ReceiveMsg->setObjectName(QString::fromUtf8("textEdit_ReceiveMsg"));
        textEdit_ReceiveMsg->setGeometry(QRect(20, 10, 431, 291));
        comboBox_2 = new QComboBox(centralwidget);
        comboBox_2->addItem(QString());
        comboBox_2->addItem(QString());
        comboBox_2->setObjectName(QString::fromUtf8("comboBox_2"));
        comboBox_2->setGeometry(QRect(560, 70, 93, 27));
        comboBox_3 = new QComboBox(centralwidget);
        comboBox_3->addItem(QString());
        comboBox_3->setObjectName(QString::fromUtf8("comboBox_3"));
        comboBox_3->setGeometry(QRect(560, 110, 93, 27));
        textEdit_ReceiveMsg_wendu = new QTextBrowser(centralwidget);
        textEdit_ReceiveMsg_wendu->setObjectName(QString::fromUtf8("textEdit_ReceiveMsg_wendu"));
        textEdit_ReceiveMsg_wendu->setGeometry(QRect(920, 20, 111, 191));
        pushButton_2 = new QPushButton(centralwidget);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(480, 270, 100, 27));
        label_7 = new QLabel(centralwidget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(870, 20, 79, 19));
        textEdit = new QTextEdit(centralwidget);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(20, 330, 431, 121));
        combox_COMx = new QComboBox(centralwidget);
        combox_COMx->setObjectName(QString::fromUtf8("combox_COMx"));
        combox_COMx->setGeometry(QRect(560, 30, 93, 27));
        customPlot = new QCustomPlot(centralwidget);
        customPlot->setObjectName(QString::fromUtf8("customPlot"));
        customPlot->setGeometry(QRect(600, 240, 511, 261));
        splitter = new QSplitter(centralwidget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(470, 30, 91, 191));
        splitter->setOrientation(Qt::Vertical);
        label = new QLabel(splitter);
        label->setObjectName(QString::fromUtf8("label"));
        splitter->addWidget(label);
        label_2 = new QLabel(splitter);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        splitter->addWidget(label_2);
        label_3 = new QLabel(splitter);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        splitter->addWidget(label_3);
        label_4 = new QLabel(splitter);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        splitter->addWidget(label_4);
        label_5 = new QLabel(splitter);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        splitter->addWidget(label_5);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 1140, 29));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        label_6->setText(QApplication::translate("MainWindow", "\346\271\277\345\272\246", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "\346\270\205\351\231\244\346\216\245\346\224\266", nullptr));
        comboBox_5->setItemText(0, QApplication::translate("MainWindow", "None", nullptr));

        pushButton_3->setText(QApplication::translate("MainWindow", "\345\217\221\351\200\201", nullptr));
        comboBox_4->setItemText(0, QApplication::translate("MainWindow", "8", nullptr));

        comboBox_2->setItemText(0, QApplication::translate("MainWindow", "9600", nullptr));
        comboBox_2->setItemText(1, QApplication::translate("MainWindow", "115200", nullptr));

        comboBox_3->setItemText(0, QApplication::translate("MainWindow", "1", nullptr));

        pushButton_2->setText(QApplication::translate("MainWindow", "\346\211\223\345\274\200\344\270\262\345\217\243", nullptr));
        label_7->setText(QApplication::translate("MainWindow", "\346\270\251\345\272\246", nullptr));
        label->setText(QApplication::translate("MainWindow", "\344\270\262\345\217\243\351\200\211\346\213\251", nullptr));
        label_2->setText(QApplication::translate("MainWindow", "\346\263\242\347\211\271\347\216\207", nullptr));
        label_3->setText(QApplication::translate("MainWindow", "\345\201\234\346\255\242\344\275\215", nullptr));
        label_4->setText(QApplication::translate("MainWindow", "\346\225\260\346\215\256\344\275\215", nullptr));
        label_5->setText(QApplication::translate("MainWindow", "\345\245\207\345\201\266\346\240\241\351\252\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
